import React, { useState } from 'react';
import { Coffee, IceCream, Star, Clock, ThermometerSun, ShoppingCart, Leaf, Cherry, Sparkles } from 'lucide-react';

function App() {
  const [selectedTopping, setSelectedTopping] = useState<string | null>(null);

  const toppings = [
    { id: 'pistache', name: 'Éclats de pistache', price: 1 },
    { id: 'noisette', name: 'Noisettes', price: 1 },
    { id: 'caramel', name: 'Caramel', price: 1 }
  ];

  const basePrice = 5.50;
  const totalPrice = selectedTopping ? basePrice + 1 : basePrice;

  return (
    <div className="min-h-screen bg-[#1a0f07]">
      {/* Hero Section */}
      <div className="relative h-screen">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1594631252845-29fc4cc8cde9?auto=format&fit=crop&q=80"
            alt="Buz Coffee"
            className="w-full h-full object-cover opacity-60"
          />
        </div>
        
        <div className="relative z-10 h-full flex flex-col items-center justify-center text-white px-4">
          <h1 className="text-5xl md:text-7xl font-bold text-center mb-6">Buz Coffee</h1>
          <p className="text-xl md:text-2xl text-center max-w-2xl mb-8">
            Un Délice Hivernal Réinventé
          </p>
          <button className="bg-[#d4a574] hover:bg-[#c69162] text-white font-bold py-3 px-8 rounded-full flex items-center gap-2 transform transition hover:scale-105">
            <ShoppingCart size={20} />
            Commander Maintenant
          </button>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-[#1a0f07] text-white py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">Ingrédients Sélectionnés</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="flex flex-col items-center text-center">
              <Coffee className="w-12 h-12 mb-4 text-[#d4a574]" />
              <h3 className="text-xl font-semibold mb-2">Café Brésilien</h3>
              <p className="text-gray-400">Grains de café soigneusement sélectionnés du Brésil</p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <IceCream className="w-12 h-12 mb-4 text-[#d4a574]" />
              <h3 className="text-xl font-semibold mb-2">Glace Turque</h3>
              <p className="text-gray-400">Glace à la vanille crémeuse d'inspiration turque</p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <Sparkles className="w-12 h-12 mb-4 text-[#d4a574]" />
              <h3 className="text-xl font-semibold mb-2">Toppings Gourmands</h3>
              <p className="text-gray-400">Une sélection de garnitures premium pour personnaliser votre dessert</p>
            </div>
          </div>
        </div>
      </div>

      {/* Product Section */}
      <div className="bg-[#241811] text-white py-20 px-4">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1">
            <img 
              src="https://images.unsplash.com/photo-1632776350300-11d5bc0fac91?auto=format&fit=crop&q=80"
              alt="Buz Coffee Detail"
              className="rounded-lg shadow-2xl"
            />
          </div>
          
          <div className="flex-1 space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold">Composez Votre Buz Coffee</h2>
            <p className="text-gray-400 text-lg">
              Une expérience gustative unique où la chaleur de notre espresso brésilien 
              rencontre la douceur glacée de notre crème glacée à la vanille turque.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <ThermometerSun className="text-[#d4a574]" />
                <span>Servi à la température idéale</span>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="text-[#d4a574]" />
                <span>Préparé à la commande</span>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-semibold">Choisissez votre topping (+1€)</h3>
              <div className="flex flex-wrap gap-3">
                {toppings.map((topping) => (
                  <button
                    key={topping.id}
                    className={`px-4 py-2 rounded-full border border-[#d4a574] transition-all ${
                      selectedTopping === topping.id 
                        ? 'bg-[#d4a574] text-white' 
                        : 'text-[#d4a574] hover:bg-[#d4a574] hover:text-white'
                    }`}
                    onClick={() => setSelectedTopping(topping.id === selectedTopping ? null : topping.id)}
                  >
                    {topping.name}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-6">
              <div className="text-2xl font-bold mb-4">{totalPrice.toFixed(2)} €</div>
              <button className="bg-[#d4a574] hover:bg-[#c69162] text-white font-bold py-3 px-8 rounded-full flex items-center gap-2 transform transition hover:scale-105">
                <ShoppingCart size={20} />
                Ajouter au Panier
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;